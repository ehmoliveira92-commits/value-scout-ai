
const BASE = "https://v3.football.api-sports.io";

export async function apiFootball(path: string) {
  const key = process.env.API_FOOTBALL_KEY;
  if (!key) throw new Error("API_FOOTBALL_KEY não configurada.");
  const response = await fetch(`${BASE}${path}`, {
    headers: { "x-apisports-key": key },
    next: { revalidate: 180 }
  });
  const data = await response.json();
  if (!response.ok) throw new Error(`API-Football respondeu ${response.status}.`);
  if (data.errors && Object.keys(data.errors).length) {
    throw new Error(Object.values(data.errors).join(" | "));
  }
  return data;
}

export function stat(stats: any[] | undefined, type: string): number {
  const item = (stats || []).find((x) => x.type === type);
  if (!item) return 0;
  if (typeof item.value === "number") return item.value;
  const value = Number(String(item.value ?? "").replace("%", ""));
  return Number.isFinite(value) ? value : 0;
}

export function average<T>(rows: T[], pick: (row: T) => number): number {
  return rows.length ? rows.reduce((sum, row) => sum + pick(row), 0) / rows.length : 0;
}
